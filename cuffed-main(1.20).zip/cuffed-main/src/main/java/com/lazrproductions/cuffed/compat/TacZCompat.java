package com.lazrproductions.cuffed.compat;

import net.minecraftforge.eventbus.api.IEventBus;

public class TacZCompat {
    public static void load(IEventBus modEventBus) {
    }
}
