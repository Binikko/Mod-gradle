package com.lazrproductions.cuffed.entity.animation;

public enum ArmRestraintAnimationFlags {
    NONE,
    ARMS_TIED_FRONT,
    ARMS_TIED_BEHIND
}
