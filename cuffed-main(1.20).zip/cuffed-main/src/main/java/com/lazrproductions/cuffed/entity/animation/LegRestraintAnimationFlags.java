package com.lazrproductions.cuffed.entity.animation;

public enum LegRestraintAnimationFlags {
    NONE
}
